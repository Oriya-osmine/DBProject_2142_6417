--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1 (Debian 17.1-1.pgdg120+1)
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DB5786David";
--
-- Name: DB5786David; Type: DATABASE; Schema: -; Owner: MyUser
--

CREATE DATABASE "DB5786David" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "DB5786David" OWNER TO "MyUser";

\unrestrict (null)
\connect "DB5786David"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ingredient; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.ingredient (
    ingredient_id integer NOT NULL,
    ingredient_name character varying(100) NOT NULL,
    unit character varying(20) NOT NULL,
    CONSTRAINT check_ingredient_name CHECK ((char_length(TRIM(BOTH FROM ingredient_name)) >= 2)),
    CONSTRAINT check_unit_standard CHECK (((unit)::text = ANY ((ARRAY['kg'::character varying, 'grams'::character varying, 'ml'::character varying, 'liters'::character varying, 'pieces'::character varying, 'oz'::character varying])::text[])))
);


ALTER TABLE public.ingredient OWNER TO "MyUser";

--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.ingredient_ingredient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ingredient_ingredient_id_seq OWNER TO "MyUser";

--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.ingredient_ingredient_id_seq OWNED BY public.ingredient.ingredient_id;


--
-- Name: menu_category; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_category (
    category_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    description text,
    CONSTRAINT check_category_name CHECK ((char_length(TRIM(BOTH FROM category_name)) >= 2))
);


ALTER TABLE public.menu_category OWNER TO "MyUser";

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_category_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_category_category_id_seq OWNER TO "MyUser";

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_category_category_id_seq OWNED BY public.menu_category.category_id;


--
-- Name: menu_change_log; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_change_log (
    change_id integer NOT NULL,
    change_description text,
    change_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    menu_item_id integer NOT NULL,
    CONSTRAINT check_valid_log_date CHECK ((change_date >= '2020-01-01 00:00:00'::timestamp without time zone))
);


ALTER TABLE public.menu_change_log OWNER TO "MyUser";

--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_change_log_change_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_change_log_change_id_seq OWNER TO "MyUser";

--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_change_log_change_id_seq OWNED BY public.menu_change_log.change_id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_item (
    menu_item_id integer NOT NULL,
    item_name character varying(150) NOT NULL,
    price numeric(10,2) NOT NULL,
    description text,
    is_available boolean DEFAULT true NOT NULL,
    added_date date DEFAULT CURRENT_DATE NOT NULL,
    calories integer,
    category_id integer NOT NULL,
    CONSTRAINT check_added_date CHECK ((added_date <= CURRENT_DATE)),
    CONSTRAINT check_calories_positive CHECK ((calories >= 0)),
    CONSTRAINT check_item_name_length CHECK ((length((item_name)::text) >= 3)),
    CONSTRAINT check_max_price CHECK ((price < (500)::numeric)),
    CONSTRAINT check_price_positive CHECK ((price > (0)::numeric))
);


ALTER TABLE public.menu_item OWNER TO "MyUser";

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_item_menu_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNER TO "MyUser";

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNED BY public.menu_item.menu_item_id;


--
-- Name: recipe; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.recipe (
    recipe_id integer NOT NULL,
    instructions text NOT NULL,
    menu_item_id integer NOT NULL,
    CONSTRAINT check_instructions_length CHECK ((char_length(instructions) > 10))
);


ALTER TABLE public.recipe OWNER TO "MyUser";

--
-- Name: recipe_ingredient; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.recipe_ingredient (
    recipe_ingredient_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    recipe_id integer NOT NULL,
    ingredient_id integer NOT NULL,
    CONSTRAINT check_quantity_positive CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.recipe_ingredient OWNER TO "MyUser";

--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq OWNER TO "MyUser";

--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq OWNED BY public.recipe_ingredient.recipe_ingredient_id;


--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.recipe_recipe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipe_recipe_id_seq OWNER TO "MyUser";

--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.recipe_recipe_id_seq OWNED BY public.recipe.recipe_id;


--
-- Name: ingredient ingredient_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient ALTER COLUMN ingredient_id SET DEFAULT nextval('public.ingredient_ingredient_id_seq'::regclass);


--
-- Name: menu_category category_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category ALTER COLUMN category_id SET DEFAULT nextval('public.menu_category_category_id_seq'::regclass);


--
-- Name: menu_change_log change_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log ALTER COLUMN change_id SET DEFAULT nextval('public.menu_change_log_change_id_seq'::regclass);


--
-- Name: menu_item menu_item_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN menu_item_id SET DEFAULT nextval('public.menu_item_menu_item_id_seq'::regclass);


--
-- Name: recipe recipe_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe ALTER COLUMN recipe_id SET DEFAULT nextval('public.recipe_recipe_id_seq'::regclass);


--
-- Name: recipe_ingredient recipe_ingredient_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient ALTER COLUMN recipe_ingredient_id SET DEFAULT nextval('public.recipe_ingredient_recipe_ingredient_id_seq'::regclass);


--
-- Data for Name: ingredient; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.ingredient (ingredient_id, ingredient_name, unit) FROM stdin;
\.
COPY public.ingredient (ingredient_id, ingredient_name, unit) FROM '$$PATH$$/3428.dat';

--
-- Data for Name: menu_category; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_category (category_id, category_name, description) FROM stdin;
\.
COPY public.menu_category (category_id, category_name, description) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: menu_change_log; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_change_log (change_id, change_description, change_date, menu_item_id) FROM stdin;
\.
COPY public.menu_change_log (change_id, change_description, change_date, menu_item_id) FROM '$$PATH$$/3434.dat';

--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_item (menu_item_id, item_name, price, description, is_available, added_date, calories, category_id) FROM stdin;
\.
COPY public.menu_item (menu_item_id, item_name, price, description, is_available, added_date, calories, category_id) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: recipe; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.recipe (recipe_id, instructions, menu_item_id) FROM stdin;
\.
COPY public.recipe (recipe_id, instructions, menu_item_id) FROM '$$PATH$$/3432.dat';

--
-- Data for Name: recipe_ingredient; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.recipe_ingredient (recipe_ingredient_id, quantity, recipe_id, ingredient_id) FROM stdin;
\.
COPY public.recipe_ingredient (recipe_ingredient_id, quantity, recipe_id, ingredient_id) FROM '$$PATH$$/3436.dat';

--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.ingredient_ingredient_id_seq', 502, true);


--
-- Name: menu_category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_category_category_id_seq', 500, true);


--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_change_log_change_id_seq', 20001, true);


--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_item_menu_item_id_seq', 503, true);


--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.recipe_ingredient_recipe_ingredient_id_seq', 20000, true);


--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.recipe_recipe_id_seq', 500, true);


--
-- Name: ingredient ingredient_ingredient_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_ingredient_name_key UNIQUE (ingredient_name);


--
-- Name: ingredient ingredient_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_pkey PRIMARY KEY (ingredient_id);


--
-- Name: menu_category menu_category_category_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_category_name_key UNIQUE (category_name);


--
-- Name: menu_category menu_category_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_pkey PRIMARY KEY (category_id);


--
-- Name: menu_change_log menu_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log
    ADD CONSTRAINT menu_change_log_pkey PRIMARY KEY (change_id);


--
-- Name: menu_item menu_item_item_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_item_name_key UNIQUE (item_name);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (menu_item_id);


--
-- Name: recipe_ingredient recipe_ingredient_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT recipe_ingredient_pkey PRIMARY KEY (recipe_ingredient_id);


--
-- Name: recipe recipe_menu_item_id_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_menu_item_id_key UNIQUE (menu_item_id);


--
-- Name: recipe recipe_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_pkey PRIMARY KEY (recipe_id);


--
-- Name: menu_item fk_category; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES public.menu_category(category_id) ON DELETE CASCADE;


--
-- Name: recipe_ingredient fk_ingredient; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT fk_ingredient FOREIGN KEY (ingredient_id) REFERENCES public.ingredient(ingredient_id) ON DELETE RESTRICT;


--
-- Name: recipe fk_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT fk_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id) ON DELETE CASCADE;


--
-- Name: menu_change_log fk_menu_item_log; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log
    ADD CONSTRAINT fk_menu_item_log FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id) ON DELETE CASCADE;


--
-- Name: recipe_ingredient fk_recipe; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT fk_recipe FOREIGN KEY (recipe_id) REFERENCES public.recipe(recipe_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

